
var $GRUNTCONFIG = {
    "DEV":{
        globaljspath:"http://m1.lenovodev.cn/gl",
        thinkpcimagespath:"http://m1.lenovodev.com/tp",
        lenovoshopurl:"http://www.lenovodev.com"
    },
    "UAT":{
    	globaljspath:"http://m1.lenovouat.cn/gl",
        thinkpcimagespath:"http://m1.lenovouat.com/tp",
        lenovoshopurl:"http://www.lenovouat.com"
    },
    "PRODUCTION":{
    	globaljspath:"http://m1.lefile.cn/gl",
        thinkpcimagespath:"http://m1.lenovo.com.cn/tp",
        lenovoshopurl:"http://www.lenovo.com.cn"
    }
}